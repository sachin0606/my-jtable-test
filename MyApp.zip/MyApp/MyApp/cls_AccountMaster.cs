﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace MyApp
{
   
    public class cls_AeraMaster
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string AreaName { get; set; }

        [Required]
        public string AgentID { get; set; }

    }

    public class cls_AccountMaster
    {
        [Key]
        public int id { get; set; }
       
        [Required]
        public DateTime transaction_date { get; set; }

        [Required]
        public int AeraId { get; set; }

        public decimal amount { get; set; }

        public string Remarks { get; set; }

        [Required]
        public int type { get; set; }

        [Required]
        public bool creditdebit { get; set; }
        [Required]
        public string decription { get; set; }

        [Required]
        public int Cardcollected { get; set; }
        [Required]
        public int MasterType { get; set; }

       
    }


}
