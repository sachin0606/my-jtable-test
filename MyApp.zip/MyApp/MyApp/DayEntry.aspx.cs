﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyApp
{
    public partial class DayEntry : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {

            }
        }



        #region Daily Transaction

        [WebMethod(EnableSession = true)]
        public static object CreateEntry(cls_AccountMaster record)
        {
            try
            {
                using (var db = new AccountmasterEntities())
                {
                    var newTblMember = new tbl_daytransaction
                    {
                        amount = record.amount,
                        AeraId = record.AeraId,
                        Cardcollected = record.Cardcollected,
                        creditdebit = record.creditdebit,
                        decription = record.decription,
                        MasterType = record.MasterType,
                        Remarks = record.Remarks,
                        transaction_date = record.transaction_date,
                        type = record.type,

                    };
                    var NewEmpAdd = db.tbl_daytransaction.Add(newTblMember);
                    db.SaveChanges();
                    return new { Result = "OK", Record = NewEmpAdd };
                }
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }


        [WebMethod(EnableSession = true)]
        public static object AccountList(int jtStartIndex, int jtPageSize, string jtSorting)
        {
            string connStr = ConfigurationManager.ConnectionStrings["myData"].ToString();
            try
            {
                List<cls_AccountMaster> accountLst = new List<cls_AccountMaster>();
                cls_AccountMaster bc_account;
                int total = 7;
                using (SqlConnection sqlCon = new SqlConnection(connStr))
                {
                    sqlCon.Open();
                    using (SqlCommand sqlCmd = new SqlCommand("select * from tbl_daytransaction", sqlCon))
                    {
                        sqlCmd.CommandType = CommandType.Text;
                        using (SqlDataReader sqlRdr = sqlCmd.ExecuteReader())
                        {
                            if (sqlRdr.HasRows)
                            {
                                while (sqlRdr.Read())
                                {
                                    bc_account = new cls_AccountMaster();
                                    bc_account.AeraId = sqlRdr.GetInt32(2);
                                    bc_account.amount = sqlRdr.GetDecimal(3);
                                    bc_account.Cardcollected = sqlRdr.GetInt32(8);
                                    bc_account.creditdebit = sqlRdr.GetBoolean(6);
                                    bc_account.decription = sqlRdr.GetString(7);
                                    bc_account.id = sqlRdr.GetInt32(0);
                                    bc_account.MasterType = sqlRdr.GetInt32(9);
                                    bc_account.Remarks = sqlRdr.GetString(4);
                                    bc_account.transaction_date = sqlRdr.GetDateTime(1);
                                    bc_account.type = sqlRdr.GetInt32(5);
                                    accountLst.Add(bc_account);
                                }
                            }

                        }

                        sqlCmd.CommandText = "select count(*) from tbl_daytransaction";
                        total = (Int32)sqlCmd.ExecuteScalar();

                    }

                }

                return new { Result = "OK", Records = accountLst, TotalRecordCount = total, };

            }


            catch (Exception ee)
            {
                return new { Result = "ERROR", Message = ee.Message };
            }

        }


        public static int GetDaytransaction_count()
        {
            try
            {
                using (var db = new AccountmasterEntities())
                {
                    return db.tbl_daytransaction.Count();

                }
            }
            catch (Exception ex)
            {
                return 0;
            }

        }



       


        [WebMethod(EnableSession = true)]
        public static object DeleteCustomer(int id)
        {
            try
            {
                using (AccountmasterEntities db = new AccountmasterEntities())
                {
                    var deletedmember = db.tbl_daytransaction.First(e => e.id == id);
                    db.tbl_daytransaction.Remove(deletedmember);
                    db.SaveChanges();
                    return new { Result = "OK" };
                }
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }





        [WebMethod(EnableSession = true)]
        public static object UpdateCustomer(cls_AccountMaster record)
        {
            try
            {
                int memid = record.id;
                using (AccountmasterEntities db = new AccountmasterEntities())
                {
                    var updateuser = (from member in db.tbl_daytransaction
                                      where (member.id == memid)
                                      select member).FirstOrDefault();
                    updateuser.type = record.type;
                    updateuser.transaction_date = record.transaction_date;
                    updateuser.Remarks = record.Remarks;
                    updateuser.MasterType = record.MasterType;
                    updateuser.decription = record.decription;
                    updateuser.creditdebit = record.creditdebit;
                    updateuser.Cardcollected = record.Cardcollected;
                    updateuser.amount = record.amount;
                    updateuser.AeraId = record.AeraId;
                   
                    db.tbl_daytransaction.Attach(updateuser);
                    var entry = db.Entry(updateuser);
                    entry.Property(e => e.AeraId).IsModified = true;
                    entry.Property(e => e.amount).IsModified = true;
                    entry.Property(e => e.Cardcollected).IsModified = true;
                    entry.Property(e => e.creditdebit).IsModified = true;
                    entry.Property(e => e.decription).IsModified = true;
                    entry.Property(e => e.MasterType).IsModified = true;
                    entry.Property(e => e.Remarks).IsModified = true;
                    entry.Property(e => e.transaction_date).IsModified = true;
                    entry.Property(e => e.type).IsModified = true;
                   


                    db.SaveChanges();
                    return new { Result = "OK", };
                }
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }


        #endregion


        #region area

        [WebMethod]
        public static object GetArea_list()
        {
            try
            {
                AccountmasterEntities db = new AccountmasterEntities();

                var cities = (from customer in db.tbl_AreaMaster
                              select customer).Select(c => new { DisplayText = c.AreaName, Value = c.Id });
                return new { Result = "OK", Options = cities };
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [WebMethod]
        public static object Getype()
        {
            try
            {
                AccountmasterEntities db = new AccountmasterEntities();

                var cities = (from customer in db.tbl_Type
                              select customer).Select(c => new { DisplayText = c.type, Value = c.id });
                return new { Result = "OK", Options = cities };
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [WebMethod]
        public static object GetMasterType()
        {
            try
            {
                AccountmasterEntities db = new AccountmasterEntities();

                var cities = (from customer in db.tbl_MasterType
                              select customer).Select(c => new { DisplayText = c.Type, Value = c.id });
                return new { Result = "OK", Options = cities };
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }
    }

#endregion
}